import numpy as np
import os
from PIL import Image

# ==========================
# 参数配置
# ==========================
IMG_SIZE = (20, 20)  # 图像大小
LEARNING_RATE = 0.1
EPOCHS = 100
ACTIVATION = 'sigmoid'  # 可以改成 'relu' 等

# ==========================
# 数据加载函数
# ==========================
def load_images(folder, img_size=IMG_SIZE):
    images = []
    for filename in os.listdir(folder):
        if filename.endswith(".png"):
            img = Image.open(os.path.join(folder, filename)).convert('L')
            img = img.resize(img_size)
            img_array = np.array(img).flatten() / 255.0  # 归一化
            images.append(img_array)
    return np.array(images)

# ==========================
# 激活函数
# ==========================
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def relu(x):
    return np.maximum(0, x)

def get_activation(name):
    if name == 'sigmoid':
        return sigmoid
    elif name == 'relu':
        return relu
    else:
        return sigmoid  # 默认

activation_func = get_activation(ACTIVATION)

# ==========================
# 损失函数（均方误差）
# ==========================
def loss(y_true, y_pred):
    return np.mean((y_true - y_pred) ** 2)

# ==========================
# 设置绝对路径
# ==========================
TRAIN_IMG_PATH = "/Users/wangliwei/Desktop/train_images"
TEST_IMG_PATH = "/Users/wangliwei/Desktop/test_images"
TRAIN_LABELS_PATH = "/Users/wangliwei/Desktop/train_labels.npy"

# ==========================
# 加载数据
# ==========================
train_X = load_images(TRAIN_IMG_PATH)
train_Y = np.load(TRAIN_LABELS_PATH)

input_size = train_X.shape[1]
output_size = train_Y.shape[1]

# ==========================
# 初始化参数
# ==========================
W = np.random.randn(input_size, output_size) * 0.01
b = np.zeros((1, output_size))

# ==========================
# 前向传播
# ==========================
def forward(X):
    return activation_func(np.dot(X, W) + b)

# ==========================
# 反向传播
# ==========================
def backward(X, Y, output):
    global W, b
    m = X.shape[0]
    if ACTIVATION == 'sigmoid':
        d_output = (output - Y) * output * (1 - output)
    elif ACTIVATION == 'relu':
        d_output = (output - Y)
        d_output[output <= 0] = 0
    dW = np.dot(X.T, d_output) / m
    db = np.sum(d_output, axis=0, keepdims=True) / m
    W -= LEARNING_RATE * dW
    b -= LEARNING_RATE * db

# ==========================
# 训练
# ==========================
for epoch in range(EPOCHS):
    output = forward(train_X)
    l = loss(train_Y, output)
    backward(train_X, train_Y, output)
    
    if epoch % 10 == 0:
        predictions = np.argmax(output, axis=1)
        labels = np.argmax(train_Y, axis=1)
        acc = np.mean(predictions == labels) * 100
        print(f"Epoch {epoch}, Loss: {l:.4f}, Training Accuracy: {acc:.2f}%")

# ==========================
# 测试
# ==========================
test_X = load_images(TEST_IMG_PATH)
test_output = forward(test_X)
predictions = np.argmax(test_output, axis=1)
print("Test Predictions:", predictions)

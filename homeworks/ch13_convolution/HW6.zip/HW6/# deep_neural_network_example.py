# deep_neural_network_example.py
import numpy as np
from sklearn.datasets import make_moons
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt


class DeepNeuralNetwork:
    def __init__(self, layers, learning_rate=0.01, output_activation="sigmoid"):
        """
        layers: list of layer sizes. Example [2, 4, 3, 1]
        learning_rate: gradient descent step size
        output_activation: "sigmoid" for binary classification
        """
        self.layers = layers
        self.learning_rate = learning_rate
        self.params = {}
        self.output_activation = output_activation
        self._initialize_weights()

    def _initialize_weights(self):
        np.random.seed(42)
        for i in range(1, len(self.layers)):
            self.params[f"W{i}"] = np.random.randn(self.layers[i], self.layers[i - 1]) * 0.01
            self.params[f"b{i}"] = np.zeros((self.layers[i], 1))

    def _activation(self, Z, func="relu"):
        if func == "relu":
            return np.maximum(0, Z)
        elif func == "sigmoid":
            return 1 / (1 + np.exp(-Z))
        else:
            return Z

    def _activation_derivative(self, A, func="relu"):
        if func == "relu":
            return (A > 0).astype(float)
        elif func == "sigmoid":
            return A * (1 - A)
        else:
            return np.ones_like(A)

    def forward(self, X):
        caches = {"A0": X}
        A = X
        for i in range(1, len(self.layers)):
            W, b = self.params[f"W{i}"], self.params[f"b{i}"]
            Z = np.dot(W, A) + b
            if i == len(self.layers) - 1:
                A = self._activation(Z, self.output_activation)
            else:
                A = self._activation(Z, "relu")
            caches[f"A{i}"], caches[f"Z{i}"] = A, Z
        return A, caches

    def compute_loss(self, Y_hat, Y):
        m = Y.shape[1]
        loss = -np.sum(Y * np.log(Y_hat + 1e-8) + (1 - Y) * np.log(1 - Y_hat + 1e-8)) / m
        return loss

    def backward(self, Y_hat, Y, caches):
        grads = {}
        m = Y.shape[1]
        dA = -(np.divide(Y, Y_hat + 1e-8) - np.divide(1 - Y, 1 - Y_hat + 1e-8))

        for i in reversed(range(1, len(self.layers))):
            A_prev = caches[f"A{i-1}"]
            A_curr = caches[f"A{i}"]
            W = self.params[f"W{i}"]

            if i == len(self.layers) - 1:
                dZ = dA * self._activation_derivative(A_curr, self.output_activation)
            else:
                dZ = dA * self._activation_derivative(A_curr, "relu")

            grads[f"dW{i}"] = np.dot(dZ, A_prev.T) / m
            grads[f"db{i}"] = np.sum(dZ, axis=1, keepdims=True) / m
            dA = np.dot(W.T, dZ)

        return grads

    def update_params(self, grads):
        for i in range(1, len(self.layers)):
            self.params[f"W{i}"] -= self.learning_rate * grads[f"dW{i}"]
            self.params[f"b{i}"] -= self.learning_rate * grads[f"db{i}"]

    def fit(self, X, Y, epochs=1000, print_loss=True):
        for epoch in range(epochs):
            Y_hat, caches = self.forward(X)
            loss = self.compute_loss(Y_hat, Y)
            grads = self.backward(Y_hat, Y, caches)
            self.update_params(grads)

            if print_loss and epoch % 100 == 0:
                print(f"Epoch {epoch}, Loss: {loss:.4f}")

    def predict(self, X):
        Y_hat, _ = self.forward(X)
        return (Y_hat > 0.5).astype(int)


# ---------------- Example Usage ---------------- #
if __name__ == "__main__":
    # Generate toy dataset
    X, y = make_moons(n_samples=1000, noise=0.2, random_state=42)
    X = X.T
    y = y.reshape(1, -1)

    X_train, X_test, y_train, y_test = train_test_split(X.T, y.T, test_size=0.2, random_state=42)
    X_train, X_test = X_train.T, X_test.T
    y_train, y_test = y_train.T, y_test.T

    # Define and train network
    nn = DeepNeuralNetwork([2, 4, 3, 1], learning_rate=0.1, output_activation="sigmoid")
    nn.fit(X_train, y_train, epochs=1000, print_loss=True)

    # Evaluate
    preds = nn.predict(X_test)
    acc = np.mean(preds == y_test) * 100
    print(f"Test Accuracy: {acc:.2f}%")

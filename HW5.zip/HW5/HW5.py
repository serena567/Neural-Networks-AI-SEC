import numpy as np

# ------------------------
# Activation Functions
# ------------------------
class Activation:
    @staticmethod
    def sigmoid(x):
        return 1 / (1 + np.exp(-x))

    @staticmethod
    def sigmoid_derivative(x):
        s = Activation.sigmoid(x)
        return s * (1 - s)

    @staticmethod
    def relu(x):
        return np.maximum(0, x)

    @staticmethod
    def relu_derivative(x):
        return (x > 0).astype(float)


# ------------------------
# Neuron
# ------------------------
class Neuron:
    def __init__(self, input_size, activation="sigmoid"):
        self.weights = np.random.randn(input_size) * 0.01
        self.bias = 0
        self.activation_name = activation
        self.z = None
        self.a = None

    def forward(self, x):
        self.z = np.dot(self.weights, x) + self.bias
        if self.activation_name == "sigmoid":
            self.a = Activation.sigmoid(self.z)
        elif self.activation_name == "relu":
            self.a = Activation.relu(self.z)
        else:
            self.a = self.z  # linear
        return self.a

    def activation_derivative(self):
        if self.activation_name == "sigmoid":
            return Activation.sigmoid_derivative(self.z)
        elif self.activation_name == "relu":
            return Activation.relu_derivative(self.z)
        else:
            return 1


# ------------------------
# Layer
# ------------------------
class Layer:
    def __init__(self, input_size, num_neurons, activation="sigmoid"):
        self.neurons = [Neuron(input_size, activation) for _ in range(num_neurons)]

    def forward(self, x):
        outputs = np.array([neuron.forward(x) for neuron in self.neurons])
        return outputs


# ------------------------
# Loss Function
# ------------------------
class LossFunction:
    @staticmethod
    def mse(y_true, y_pred):
        return np.mean((y_true - y_pred) ** 2)

    @staticmethod
    def mse_derivative(y_true, y_pred):
        return (y_pred - y_true)


# ------------------------
# Model
# ------------------------
class NeuralNetwork:
    def __init__(self, input_size, hidden_size, output_size):
        self.hidden_layer = Layer(input_size, hidden_size, activation="sigmoid")
        self.output_layer = Layer(hidden_size, output_size, activation="sigmoid")

    def forward(self, x):
        self.a1 = self.hidden_layer.forward(x)
        self.a2 = self.output_layer.forward(self.a1)
        return self.a2

    def backward(self, x, y, lr=0.1):
        # Output layer error
        for j, neuron in enumerate(self.output_layer.neurons):
            error = LossFunction.mse_derivative(y[j], neuron.a) * neuron.activation_derivative()
            # Update weights
            for k in range(len(neuron.weights)):
                neuron.weights[k] -= lr * error * self.a1[k]
            neuron.bias -= lr * error

        # Hidden layer error
        for i, neuron in enumerate(self.hidden_layer.neurons):
            # sum over output errors * weights
            error_sum = 0
            for j, out_neuron in enumerate(self.output_layer.neurons):
                out_error = LossFunction.mse_derivative(y[j], out_neuron.a) * out_neuron.activation_derivative()
                error_sum += out_error * out_neuron.weights[i]
            hidden_error = error_sum * neuron.activation_derivative()
            # Update weights
            for k in range(len(neuron.weights)):
                neuron.weights[k] -= lr * hidden_error * x[k]
            neuron.bias -= lr * hidden_error


# ------------------------
# Training
# ------------------------
class Trainer:
    def __init__(self, model, lr=0.1, epochs=1000):
        self.model = model
        self.lr = lr
        self.epochs = epochs

    def fit(self, X, Y):
        for epoch in range(self.epochs):
            loss = 0
            for x, y in zip(X, Y):
                y_pred = self.model.forward(x)
                loss += LossFunction.mse(y, y_pred)
                self.model.backward(x, y, self.lr)
            if epoch % 100 == 0:
                print(f"Epoch {epoch}, Loss={loss/len(X):.4f}")

    def predict(self, X):
        return [self.model.forward(x) for x in X]


# ------------------------
# Test on XOR
# ------------------------
if __name__ == "__main__":
    # XOR data
    X = np.array([[0,0],[0,1],[1,0],[1,1]])
    Y = np.array([[0],[1],[1],[0]])

    # Build and train
    nn = NeuralNetwork(input_size=2, hidden_size=2, output_size=1)
    trainer = Trainer(nn, lr=0.5, epochs=2000)
    trainer.fit(X, Y)

    # Predictions
    for x in X:
        print(f"Input {x} -> Predicted {trainer.model.forward(x)}")
